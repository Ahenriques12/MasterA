var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1686290088505.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 6.1 - Account" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632-1686290088505.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="360.0px" datasizeheight="60.0px" datasizewidthpx="359.9999999999998" datasizeheightpx="60.0" dataX="0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="360.0px" datasizeheight="50.0px" datasizewidthpx="359.9999999999998" datasizeheightpx="50.000000000000114" dataX="0.0" dataY="60.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="SETTINGS"   datasizewidth="241.0px" datasizeheight="32.0px" dataX="11.0" dataY="14.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">SETTINGS</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="71.0px" datasizeheight="64.0px" dataX="260.0" dataY="-4.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/9d1e1200-4eb5-4818-aaad-1708d5f162dc.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Customize Your Style!"   datasizewidth="158.3px" datasizeheight="18.0px" dataX="56.4" dataY="76.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Customize Your Style!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="71.0px" datasizeheight="64.0px" dataX="64.5" dataY="128.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/f0840a10-124f-4b28-afe6-611b8456635c.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="Max Richardson"   datasizewidth="115.6px" datasizeheight="18.0px" dataX="167.4" dataY="142.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Max Richardson</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="richtext autofit firer ie-background commentable non-processed" customid="+351932343xxx"   datasizewidth="113.4px" datasizeheight="18.0px" dataX="167.4" dataY="174.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">+351932343xxx</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="ACCOUNT"   datasizewidth="159.5px" datasizeheight="56.0px" dataX="100.2" dataY="238.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">ACCOUNT</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_7" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="200.0px" datasizeheight="120.0px" datasizewidthpx="200.0" datasizeheightpx="120.0" dataX="80.0" dataY="414.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0">Change your account data</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="44.0" dataY="297.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Name"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="44.0" dataY="356.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Phone N&ordm;"/></div></div>  </div></div></div>\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="36.0px" datasizeheight="45.3px" dataX="8.0" dataY="297.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/85a35f4a-b665-40ce-944b-446bb792166f.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="36.0px" datasizeheight="45.0px" dataX="8.0" dataY="356.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/f0ac6e5d-f5c0-4130-8ddf-65a241c763f8.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="SAVE"   datasizewidth="104.0px" datasizeheight="40.0px" dataX="128.0" dataY="494.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_4_0">SAVE</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_248" class="path firer commentable hidden non-processed" customid="Thumb Up"   datasizewidth="85.0px" datasizeheight="65.6px" dataX="217.3" dataY="448.4"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="85.0" height="65.6478271484375" viewBox="217.27343749254834 448.35217391304303 85.0 65.6478271484375" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_248-96b0c" d="M217.27343749254834 513.9999999999995 L232.7279829393354 513.9999999999995 L232.7279829393354 474.61130434782564 L217.27343749254834 474.61130434782564 L217.27343749254834 513.9999999999995 Z M302.2734374498771 477.8936956521735 C302.2734374498771 474.2830651391326 298.79616481646633 471.3289130434778 294.5461647264836 471.3289130434778 L270.16661950525605 471.3289130434778 L273.83707400280986 456.32838421914846 L273.95298309107 455.27801902523464 C273.95298309107 453.93223860219075 273.2961649026728 452.6849298243674 272.25298310113504 451.79868443044586 L268.1575286708668 448.35217391304303 L242.73480170567413 469.98313310954836 C241.30525485167902 471.16479285219395 240.45525566272892 472.8059885043679 240.45525566272892 474.61130434782564 L240.45525566272892 507.4352173913039 C240.45525566272892 511.0458479043449 243.93252829613974 513.9999999999995 248.18252838612244 513.9999999999995 L282.9552556413933 513.9999999999995 C286.1620737571202 513.9999999999995 288.9052554910203 512.3588043478256 290.06434667587814 509.9954825147853 L301.7325284145093 486.85462319306663 C302.0802557008795 486.09967317937145 302.2734375074498 485.3118992839361 302.2734375074498 484.45847747828606 L302.2734375074498 477.89369486959043 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_248-96b0c" fill="#1EAAF1" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_9" class="richtext manualfit firer ie-background commentable hidden non-processed" customid="SAVED!"   datasizewidth="167.4px" datasizeheight="58.0px" dataX="64.6" dataY="465.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0">SAVED!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed" customid="Navigation bar with labels" datasizewidth="360.0px" datasizeheight="63.0px" dataX="1.2" dataY="0.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel 3"  datasizewidth="360.0px" datasizeheight="63.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Table_1" class="percentage table firer commentable pin hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Table"  datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="-0.0" originalwidth="360.0px" originalheight="80.0px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <table summary="">\
                        <tbody>\
                          <tr>\
                            <td id="s-Cell_1" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_3_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_1" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 1"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_2" customid="Cell 2" class="cellcontainer firer click ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_4_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_2" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 2"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_3" customid="Cell 3" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_5_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_3" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 3"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_4" customid="Cell 4" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_6" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="55.0px" datasizewidthpx="59.00000000000023" datasizeheightpx="55.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_6_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_4" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 4"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                        </tbody>\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Tabs" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="HOME"   datasizewidth="92.0px" datasizeheight="31.0px" dataX="-0.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_1_0">HOME</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="FAVOURITES"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="92.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_3_0">FAVOURITES</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="FRIENDS"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="182.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_5_0">FRIENDS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="SETTINGS"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="272.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_6_0">SETTINGS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;