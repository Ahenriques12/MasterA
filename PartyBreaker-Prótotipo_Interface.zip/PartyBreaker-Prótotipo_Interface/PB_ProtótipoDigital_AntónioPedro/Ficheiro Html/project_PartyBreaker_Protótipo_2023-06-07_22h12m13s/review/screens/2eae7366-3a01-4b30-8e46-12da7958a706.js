var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1686290088505.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-2eae7366-3a01-4b30-8e46-12da7958a706" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 6 - Settings" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/2eae7366-3a01-4b30-8e46-12da7958a706-1686290088505.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="360.0px" datasizeheight="60.0px" datasizewidthpx="359.9999999999998" datasizeheightpx="60.0" dataX="0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="360.0px" datasizeheight="50.0px" datasizewidthpx="359.9999999999998" datasizeheightpx="50.000000000000114" dataX="0.0" dataY="60.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="SETTINGS"   datasizewidth="241.0px" datasizeheight="32.0px" dataX="11.0" dataY="14.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">SETTINGS</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="71.0px" datasizeheight="64.0px" dataX="260.0" dataY="-4.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/9d1e1200-4eb5-4818-aaad-1708d5f162dc.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Customize Your Style!"   datasizewidth="158.3px" datasizeheight="18.0px" dataX="56.4" dataY="76.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Customize Your Style!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="71.0px" datasizeheight="64.0px" dataX="64.5" dataY="128.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/f0840a10-124f-4b28-afe6-611b8456635c.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="Max Richardson"   datasizewidth="115.6px" datasizeheight="18.0px" dataX="167.4" dataY="142.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Max Richardson</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="richtext autofit firer ie-background commentable non-processed" customid="+351932343xxx"   datasizewidth="113.4px" datasizeheight="18.0px" dataX="167.4" dataY="174.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">+351932343xxx</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="ACCOUNT"   datasizewidth="159.5px" datasizeheight="56.0px" dataX="100.2" dataY="238.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">ACCOUNT</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="DARK MODE"   datasizewidth="159.5px" datasizeheight="56.0px" dataX="100.2" dataY="320.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">DARK MODE</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="NOTIFICATIONS"   datasizewidth="159.5px" datasizeheight="56.0px" dataX="100.2" dataY="396.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">NOTIFICATIONS</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="LANGUAGE"   datasizewidth="159.5px" datasizeheight="56.0px" dataX="100.2" dataY="473.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_4_0">LANGUAGE</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed" customid="Navigation bar with labels" datasizewidth="360.0px" datasizeheight="63.0px" dataX="1.2" dataY="0.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel 3"  datasizewidth="360.0px" datasizeheight="63.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Table_1" class="percentage table firer commentable pin hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Table"  datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="-0.0" originalwidth="360.0px" originalheight="80.0px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <table summary="">\
                        <tbody>\
                          <tr>\
                            <td id="s-Cell_1" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_3_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_1" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 1"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_2" customid="Cell 2" class="cellcontainer firer click ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_4_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_2" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 2"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_3" customid="Cell 3" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_5_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_3" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 3"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_4" customid="Cell 4" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_6" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="55.0px" datasizewidthpx="59.00000000000023" datasizeheightpx="55.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_6_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_4" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 4"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                        </tbody>\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Tabs" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="HOME"   datasizewidth="92.0px" datasizeheight="31.0px" dataX="-0.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_5_0">HOME</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="FAVOURITES"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="92.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_6_0">FAVOURITES</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_7" class="button multiline manualfit firer click commentable non-processed" customid="FRIENDS"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="182.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_7_0">FRIENDS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_8" class="button multiline manualfit firer click commentable non-processed" customid="SETTINGS"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="272.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_8_0">SETTINGS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;