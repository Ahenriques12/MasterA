var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1686290088505.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-fe0140cd-a3a3-4d96-8def-0ed0454203b8" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 2 - Login" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/fe0140cd-a3a3-4d96-8def-0ed0454203b8-1686290088505.css" />\
      <div class="freeLayout">\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="368.0px" datasizeheight="640.0px" dataX="-8.0" dataY="-0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e1041382-e7e4-41e8-b8ff-494091f26a28.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="WELCOME!"   datasizewidth="148.1px" datasizeheight="43.0px" dataX="44.0" dataY="148.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">WELCOME!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Sign In To Continue"   datasizewidth="234.0px" datasizeheight="19.0px" dataX="44.0" dataY="267.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Sign In To Continue</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="228.0" dataY="79.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/873fee20-9297-4389-8819-9c9732830ef3.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="44.0" dataY="297.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Name"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="44.0" dataY="367.6" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Phone N&ordm;"/></div></div>  </div></div></div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="36.0px" datasizeheight="45.3px" dataX="8.0" dataY="297.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/85a35f4a-b665-40ce-944b-446bb792166f.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="36.0px" datasizeheight="45.0px" dataX="8.0" dataY="367.6"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/f0ac6e5d-f5c0-4130-8ddf-65a241c763f8.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_2" class="button multiline manualfit firer click swiperight commentable non-processed" customid="----&raquo;"   datasizewidth="129.0px" datasizeheight="40.0px" dataX="115.5" dataY="492.4" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">----&raquo;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;