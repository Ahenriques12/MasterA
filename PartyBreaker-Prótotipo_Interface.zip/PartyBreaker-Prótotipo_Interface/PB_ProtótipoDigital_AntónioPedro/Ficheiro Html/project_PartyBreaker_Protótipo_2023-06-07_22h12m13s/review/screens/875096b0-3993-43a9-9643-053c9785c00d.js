var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1686290088505.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-875096b0-3993-43a9-9643-053c9785c00d" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 3 - Main Menu" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/875096b0-3993-43a9-9643-053c9785c00d-1686290088505.css" />\
      <div class="freeLayout">\
      <div id="s-Group_16" class="group firer ie-background commentable non-processed" customid="Maps screen" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Image_1" class="image lockV firer ie-background commentable non-processed" customid="Map Image"   datasizewidth="321.9px" datasizeheight="643.9px" dataX="20.3" dataY="-0.5" aspectRatio="2.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/b9343106-236e-420d-9261-6c26017d12e3.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_15" class="group firer ie-background commentable non-processed" customid="FAB directions" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_9" class="rectangle manualfit firer commentable non-processed" customid="bg"   datasizewidth="55.0px" datasizeheight="13.0px" datasizewidthpx="55.03101514594783" datasizeheightpx="13.015572418288912" dataX="275.0" dataY="504.3" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_9_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_100" class="path firer commentable non-processed" customid="directions-icon"   datasizewidth="26.0px" datasizeheight="26.0px" dataX="289.7" dataY="507.8"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="26.000158309936523" height="26.000158309936523" viewBox="289.69372466034315 507.79544332452053 26.000158309936523 26.000158309936523" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_100-87509" d="M315.31353559198726 519.8787878116871 L303.6105385253384 508.1757907450379 C303.10340867105174 507.6686608907512 302.2841988825868 507.6686608907512 301.77706902830005 508.1757907450379 L290.0740719616512 519.8787878116871 C289.5669421073645 520.3859176659737 289.5669421073645 521.2051274544388 290.0740719616512 521.7122573087254 L301.77706902830005 533.4152543753745 C302.2841988825868 533.9223842296612 303.10340867105174 533.9223842296612 303.6105385253384 533.4152543753745 L315.31353559198726 521.7122573087254 C315.820665446274 521.2181307721119 315.820665446274 520.3989209836468 315.31353559198726 519.8787878116871 Z M305.28796929538186 524.0528568150623 L305.28796929538186 520.8020242965487 L300.08663726576015 520.8020242965487 L300.08663726576015 524.7030233187651 L297.48597125094926 524.7030233187651 L297.48597125094926 519.5016912891432 C297.48597125094926 518.786508119569 298.07112108878056 518.2013582817377 298.7863042583547 518.2013582817377 L305.28796929538186 518.2013582817377 L305.28796929538186 514.950525763224 L309.83913482130083 519.5016912891432 L305.28796929538186 524.0528568150623 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_100-87509" fill="#FFFFFF" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot"   datasizewidth="58.0px" datasizeheight="13.9px" dataX="273.5" dataY="504.3"  >\
            <div class="clickableSpot"></div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_17" class="group firer ie-background commentable non-processed" customid="location" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="shapewrapper-s-Ellipse_22" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_22 non-processed"   datasizewidth="51.1px" datasizeheight="12.1px" datasizewidthpx="51.100228349809015" datasizeheightpx="12.085888674125613" dataX="277.4" dataY="456.1" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_22" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_22)">\
                              <ellipse id="s-Ellipse_22" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse" cx="25.550114174904508" cy="6.042944337062806" rx="25.550114174904508" ry="6.042944337062806">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_22" class="clipPath">\
                              <ellipse cx="25.550114174904508" cy="6.042944337062806" rx="25.550114174904508" ry="6.042944337062806">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_22" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_22_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Path_78" class="path firer commentable non-processed" customid="gps-fixed-icon"   datasizewidth="22.0px" datasizeheight="22.0px" dataX="292.1" dataY="459.6"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="292.10817498953475 459.57534591501536 22.0 22.0" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_78-87509" d="M303.1081749895351 466.5753459150154 C300.89817495138806 466.5753459150154 299.108174989535 468.36534587686845 299.108174989535 470.5753459150154 C299.108174989535 472.7853459531624 300.89817495138806 474.5753459150154 303.1081749895351 474.5753459150154 C305.3181750276821 474.5753459150154 307.1081749895352 472.7853459531624 307.1081749895352 470.5753459150154 C307.1081749895352 468.36534587686845 305.3181750276821 466.5753459150154 303.1081749895351 466.5753459150154 Z M312.0481745699187 469.5753459150154 C311.588174561574 465.4053458387215 308.27817458899204 462.0953458959419 304.10817451269793 461.6353458577949 L304.10817451269793 459.57534591501536 L302.1081745126979 459.57534591501536 L302.1081745126979 461.6353458577949 C297.93817491324097 462.0953458959419 294.6281749704613 465.4053458387215 294.16817493231434 469.5753459150154 L292.10817498953475 469.5753459150154 L292.10817498953475 471.5753459150154 L294.16817493231434 471.5753459150154 C294.628174940659 475.74534599130936 297.93817491324097 479.05534593408896 302.10817498953503 479.51534597223593 L302.10817498953503 481.5753459150155 L304.1081749895351 481.5753459150155 L304.1081749895351 479.51534597223593 C308.2781750658292 479.0553459638913 311.58817500860886 475.74534599130936 312.04817504675583 471.5753459150154 L314.1081749895354 471.5753459150154 L314.1081749895354 469.5753459150154 L312.04817504675583 469.5753459150154 Z M303.1081749895351 477.5753459150155 C299.2381751039759 477.5753459150155 296.10817498953486 474.4453458005745 296.10817498953486 470.5753459150154 C296.10817498953486 466.70534602945634 299.2381751039759 463.57534591501536 303.1081749895351 463.57534591501536 C306.9781748750943 463.57534591501536 310.1081749895353 466.70534602945634 310.1081749895353 470.5753459150154 C310.1081749895353 474.4453458005745 306.9781748750943 477.5753459150155 303.1081749895351 477.5753459150155 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_78-87509" fill="#6750A4" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot"   datasizewidth="58.0px" datasizeheight="13.9px" dataX="273.4" dataY="454.9"  >\
            <div class="clickableSpot"></div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_59" class="group firer ie-background commentable non-processed" customid="Search input" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Input_7" class="text firer keyup commentable non-processed" customid="Input"  datasizewidth="309.0px" datasizeheight="59.0px" dataX="25.5" dataY="119.1" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search"/></div></div>  </div></div></div>\
        <div id="s-Path_79" class="path firer commentable non-processed" customid="search-icon"   datasizewidth="15.0px" datasizeheight="15.0px" dataX="45.5" dataY="142.1"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="15.0" viewBox="45.50000000000023 142.13868566870178 15.0 15.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_79-87509" d="M56.220411804100145 151.5726480563097 L55.542881759678224 151.5726480563097 L55.302744534244006 151.34108715213975 C56.14322470824622 150.36338573567164 56.64922827626414 149.09408855275692 56.64922827626414 147.71329980683373 C56.64922827626414 144.63439740583183 54.15351653913408 142.13868566870178 51.07461413813218 142.13868566870178 C47.995711737130286 142.13868566870178 45.50000000000023 144.63439740583183 45.50000000000023 147.71329980683373 C45.50000000000023 150.79220220783563 47.995711737130286 153.2879139449657 51.07461413813218 153.2879139449657 C52.45540319076879 153.2879139449657 53.72469986249446 152.7819105303045 54.702401508997646 151.9414301773861 L54.933962413167606 152.18156740282032 L54.933962413167606 152.85909744724225 L59.22212713480757 157.13868564314234 L60.50000000000023 155.86081277794966 L56.220411804100145 151.5726480563097 Z M51.07461413813218 151.5726480563097 C48.93910830305208 151.5726480563097 47.21526588865621 149.84880564191383 47.21526588865621 147.71329980683373 C47.21526588865621 145.57779397175364 48.93910830305208 143.85395155735776 51.07461413813218 143.85395155735776 C53.21011997321229 143.85395155735776 54.933962387608155 145.57779397175364 54.933962387608155 147.71329980683373 C54.933962387608155 149.84880564191383 53.21011997321229 151.5726480563097 51.07461413813218 151.5726480563097 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_79-87509" fill="#6750A4" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_41" class="group firer ie-background commentable non-processed" customid="Tabs" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Button_11" class="button multiline manualfit firer click commentable non-processed" customid="PARTY"   datasizewidth="155.0px" datasizeheight="44.0px" dataX="19.5" dataY="74.9" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_11_0">PARTY</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_12" class="button multiline manualfit firer click commentable non-processed" customid="DINNER"   datasizewidth="155.0px" datasizeheight="44.0px" dataX="186.5" dataY="74.9" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_12_0">DINNER</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="90.0px" datasizeheight="75.0px" dataX="48.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="resources/jim/images/common/cross.svg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="360.0px" datasizeheight="79.0px" datasizewidthpx="360.00000000000153" datasizeheightpx="79.0" dataX="-0.0" dataY="-4.4" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="90.0px" datasizeheight="75.0px" dataX="215.0" dataY="-0.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/bdbed2c2-6d08-46ed-b811-96640fd8d74c.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="90.0px" datasizeheight="75.0px" dataX="51.0" dataY="-0.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/51588be0-5e30-42db-ac38-3f83e6b9d592.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Path_386" class="path firer commentable hidden non-processed" customid="User"   datasizewidth="47.2px" datasizeheight="50.5px" dataX="61.1" dataY="464.1"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="47.165401458740234" height="50.533687591552734" viewBox="61.08270139288356 464.1467315013024 47.165401458740234 50.533687591552734" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_386-87509" d="M84.66540278576608 489.4135751531164 C91.18012415800096 489.4135751531164 96.45675348220735 483.76011900650474 96.45675348220735 476.7801533272094 C96.45675348220735 469.8001876479141 91.18012415800096 464.1467315013024 84.66540278576608 464.1467315013024 C78.1506814135312 464.1467315013024 72.87405208932482 469.8001876479141 72.87405208932482 476.7801533272094 C72.87405208932482 483.76011900650474 78.1506814135312 489.4135751531164 84.66540278576608 489.4135751531164 Z M84.66540278576608 495.73028606606994 C76.79467597098937 495.73028606606994 61.08270139288356 499.9624824831703 61.08270139288356 508.36370789197696 L61.08270139288356 514.6804188049305 L108.24810417864862 514.6804188049305 L108.24810417864862 508.36370789197696 C108.24810417864862 499.962482106665 92.5361296005428 495.73028606606994 84.66540278576608 495.73028606606994 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_386-87509" fill="#E2202C" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_276" class="path firer commentable hidden non-processed" customid="Business"   datasizewidth="47.0px" datasizeheight="64.0px" dataX="37.6" dataY="232.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="47.0" height="64.0" viewBox="37.582701392882655 232.51141340595876 47.0 64.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_276-87509" d="M61.082701392882655 246.733635628181 L61.082701392882655 232.51141340595876 L37.582701392882655 232.51141340595876 L37.582701392882655 296.51141340595876 L84.58270139288265 296.51141340595876 L84.58270139288265 246.733635628181 L61.082701392882655 246.733635628181 Z M46.98270139288266 289.4003022948477 L42.28270139288266 289.4003022948477 L42.28270139288266 282.28919118373653 L46.98270139288266 282.28919118373653 L46.98270139288266 289.4003022948477 Z M46.98270139288266 275.17808007262545 L42.28270139288266 275.17808007262545 L42.28270139288266 268.0669689615143 L46.98270139288266 268.0669689615143 L46.98270139288266 275.17808007262545 Z M46.98270139288266 260.9558578504032 L42.28270139288266 260.9558578504032 L42.28270139288266 253.8447467392921 L46.98270139288266 253.8447467392921 L46.98270139288266 260.9558578504032 Z M46.98270139288266 246.733635628181 L42.28270139288266 246.733635628181 L42.28270139288266 239.62252451706988 L46.98270139288266 239.62252451706988 L46.98270139288266 246.733635628181 Z M56.38270139288265 289.4003022948477 L51.682701392882656 289.4003022948477 L51.682701392882656 282.28919118373653 L56.38270139288265 282.28919118373653 L56.38270139288265 289.4003022948477 Z M56.38270139288265 275.17808007262545 L51.682701392882656 275.17808007262545 L51.682701392882656 268.0669689615143 L56.38270139288265 268.0669689615143 L56.38270139288265 275.17808007262545 Z M56.38270139288265 260.9558578504032 L51.682701392882656 260.9558578504032 L51.682701392882656 253.8447467392921 L56.38270139288265 253.8447467392921 L56.38270139288265 260.9558578504032 Z M56.38270139288265 246.733635628181 L51.682701392882656 246.733635628181 L51.682701392882656 239.62252451706988 L56.38270139288265 239.62252451706988 L56.38270139288265 246.733635628181 Z M79.88270139288265 289.4003022948477 L61.082701392882655 289.4003022948477 L61.082701392882655 282.28919118373653 L65.78270139288266 282.28919118373653 L65.78270139288266 275.17808007262545 L61.082701392882655 275.17808007262545 L61.082701392882655 268.0669689615143 L65.78270139288266 268.0669689615143 L65.78270139288266 260.9558578504032 L61.082701392882655 260.9558578504032 L61.082701392882655 253.8447467392921 L79.88270139288265 253.8447467392921 L79.88270139288265 289.4003022948477 Z M75.18270139288265 260.9558578504032 L70.48270139288266 260.9558578504032 L70.48270139288266 268.0669689615143 L75.18270139288265 268.0669689615143 L75.18270139288265 260.9558578504032 Z M75.18270139288265 275.17808007262545 L70.48270139288266 275.17808007262545 L70.48270139288266 282.28919118373653 L75.18270139288265 282.28919118373653 L75.18270139288265 275.17808007262545 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_276-87509" fill="#1EAAF1" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_215" class="path firer commentable hidden non-processed" customid="Near Me"   datasizewidth="35.3px" datasizeheight="38.0px" dataX="25.7" dataY="310.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="35.33270263671875" height="37.985130310058594" viewBox="25.7499999999997 310.0 35.33270263671875 37.985130310058594" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_215-87509" d="M61.082701392882925 310.0 L25.7499999999997 325.89044482773176 L25.7499999999997 327.95852408224704 L39.17642682881434 333.5507793016644 L44.358555168361136 347.98512842527157 L46.28222450385799 347.98512842527157 L61.082701392882925 310.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_215-87509" fill="#E2202C" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_164" class="path firer commentable hidden non-processed" customid="Store"   datasizewidth="53.0px" datasizeheight="54.4px" dataX="180.0" dataY="205.3"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="53.0" height="54.37272644042969" viewBox="180.0000000000003 205.3250502698737 53.0 54.37272644042969" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_164-87509" d="M230.0555555555562 205.3250502698737 L182.94444444444477 205.3250502698737 L182.94444444444477 212.12164105389493 L230.0555555555562 212.12164105389493 L230.0555555555562 205.3250502698737 Z M233.00000000000065 239.3080041899798 L233.00000000000065 232.5114134059586 L230.0555555555562 215.51993644590556 L182.94444444444477 215.51993644590556 L180.0000000000003 232.5114134059586 L180.0000000000003 239.3080041899798 L182.94444444444477 239.3080041899798 L182.94444444444477 259.69777654204347 L212.3888888888894 259.69777654204347 L212.3888888888894 239.3080041899798 L224.16666666666725 239.3080041899798 L224.16666666666725 259.69777654204347 L230.0555555555562 259.69777654204347 L230.0555555555562 239.3080041899798 L233.00000000000065 239.3080041899798 Z M206.50000000000048 252.90118575802225 L188.8333333333337 252.90118575802225 L188.8333333333337 239.3080041899798 L206.50000000000048 239.3080041899798 L206.50000000000048 252.90118575802225 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_164-87509" fill="#FEE94E" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_277" class="path firer commentable hidden non-processed" customid="Business"   datasizewidth="55.0px" datasizeheight="73.0px" dataX="250.0" dataY="339.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="55.0" height="73.0148696899414" viewBox="249.99999999999994 338.9851284252713 55.0 73.0148696899414" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_277-87509" d="M277.5 355.2106554418776 L277.5 338.9851284252713 L249.99999999999994 338.9851284252713 L249.99999999999994 411.9999999999995 L305.00000000000006 411.9999999999995 L305.00000000000006 355.2106554418776 L277.5 355.2106554418776 Z M260.99999999999994 403.88723649169634 L255.49999999999994 403.88723649169634 L255.49999999999994 395.77447298339325 L260.99999999999994 395.77447298339325 L260.99999999999994 403.88723649169634 Z M260.99999999999994 387.6617094750901 L255.49999999999994 387.6617094750901 L255.49999999999994 379.54894596678696 L260.99999999999994 379.54894596678696 L260.99999999999994 387.6617094750901 Z M260.99999999999994 371.4361824584838 L255.49999999999994 371.4361824584838 L255.49999999999994 363.32341895018067 L260.99999999999994 363.32341895018067 L260.99999999999994 371.4361824584838 Z M260.99999999999994 355.2106554418776 L255.49999999999994 355.2106554418776 L255.49999999999994 347.09789193357443 L260.99999999999994 347.09789193357443 L260.99999999999994 355.2106554418776 Z M272.0 403.88723649169634 L266.5 403.88723649169634 L266.5 395.77447298339325 L272.0 395.77447298339325 L272.0 403.88723649169634 Z M272.0 387.6617094750901 L266.5 387.6617094750901 L266.5 379.54894596678696 L272.0 379.54894596678696 L272.0 387.6617094750901 Z M272.0 371.4361824584838 L266.5 371.4361824584838 L266.5 363.32341895018067 L272.0 363.32341895018067 L272.0 371.4361824584838 Z M272.0 355.2106554418776 L266.5 355.2106554418776 L266.5 347.09789193357443 L272.0 347.09789193357443 L272.0 355.2106554418776 Z M299.50000000000006 403.88723649169634 L277.5 403.88723649169634 L277.5 395.77447298339325 L283.0 395.77447298339325 L283.0 387.6617094750901 L277.5 387.6617094750901 L277.5 379.54894596678696 L283.0 379.54894596678696 L283.0 371.4361824584838 L277.5 371.4361824584838 L277.5 363.32341895018067 L299.50000000000006 363.32341895018067 L299.50000000000006 403.88723649169634 Z M294.00000000000006 371.4361824584838 L288.5 371.4361824584838 L288.5 379.54894596678696 L294.00000000000006 379.54894596678696 L294.00000000000006 371.4361824584838 Z M294.00000000000006 387.6617094750901 L288.5 387.6617094750901 L288.5 395.77447298339325 L294.00000000000006 395.77447298339325 L294.00000000000006 387.6617094750901 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_277-87509" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_287" class="path firer commentable hidden non-processed" customid="Account Balance"   datasizewidth="45.5px" datasizeheight="55.8px" dataX="180.0" dataY="489.4"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="45.5" height="55.767032623291016" viewBox="179.9999999999988 489.4135751531164 45.5 55.767032623291016" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_287-87509" d="M190.77631578947262 514.5087401285575 L185.98684210526204 514.5087401285575 L185.98684210526204 534.0272017761228 L190.77631578947262 534.0272017761228 L190.77631578947262 514.5087401285575 Z M205.14473684210438 514.5087401285575 L200.3552631578938 514.5087401285575 L200.3552631578938 534.0272017761228 L205.14473684210438 534.0272017761228 L205.14473684210438 514.5087401285575 Z M225.49999999999937 539.6039051039986 L179.9999999999988 539.6039051039986 L179.9999999999988 545.1806084318744 L225.49999999999937 545.1806084318744 L225.49999999999937 539.6039051039986 Z M219.51315789473614 514.5087401285575 L214.72368421052556 514.5087401285575 L214.72368421052556 534.0272017761228 L219.51315789473614 534.0272017761228 L219.51315789473614 514.5087401285575 Z M202.7499999999991 495.7152505518191 L215.22657675492061 503.3553334728059 L190.27342096127856 503.3553334728059 L202.7499999999991 495.7152498870243 M202.7499999999991 489.4135751531164 L179.9999999999988 503.3553334728059 L179.9999999999988 508.9320368006817 L225.49999999999937 508.9320368006817 L225.49999999999937 503.3553334728059 L202.7499999999991 489.4135751531164 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_287-87509" fill="#673FB4" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="299.0px" datasizeheight="57.0px" datasizewidthpx="299.0" datasizeheightpx="56.999999999999886" dataX="25.5" dataY="134.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer commentable hidden non-processed" customid="Ellipse 1" cx="149.5" cy="28.499999999999943" rx="149.5" ry="28.499999999999943">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="149.5" cy="28.499999999999943" rx="149.5" ry="28.499999999999943">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0">Searching for places near You...</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Path_42" class="path firer commentable hidden non-processed" customid="Search"   datasizewidth="36.2px" datasizeheight="26.1px" dataX="286.9" dataY="149.6"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="36.244998931884766" height="26.12342071533203" viewBox="286.8775000572207 149.6386871337885 36.244998931884766 26.12342071533203" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_42-87509" d="M312.7815883647378 166.0685122618381 L311.14444993923536 166.0685122618381 L310.5641983586766 165.665234719943 C312.59507861271163 163.96250763242378 313.8177518970385 161.75194860176572 313.8177518970385 159.34722016399962 C313.8177518970385 153.9851224624823 307.7872804552605 149.6386871337885 300.34762597712955 149.6386871337885 C292.9079714989987 149.6386871337885 286.8775000572207 153.9851224624823 286.8775000572207 159.34722016399962 C286.8775000572207 164.70931786551694 292.9079714989987 169.05575319421075 300.34762597712955 169.05575319421075 C303.68407258078264 169.05575319421075 306.7511164288785 168.17451715833258 309.11356949991983 166.71076898395472 L309.67309782959586 167.12898271626742 L309.67309782959586 168.30894291660422 L320.0347331526027 175.7621087010114 L323.12249994278056 173.53661459276975 L312.7815883647378 166.0685122618381 Z M300.34762597712955 166.0685122618381 C295.1875320605902 166.0685122618381 291.0221541864234 163.066334782941 291.0221541864234 159.34722016399962 C291.0221541864234 155.62810554505825 295.1875320605902 152.62592806616115 300.34762597712955 152.62592806616115 C305.50771989366893 152.62592806616115 309.6730977678357 155.62810554505825 309.6730977678357 159.34722016399962 C309.6730977678357 163.066334782941 305.50771989366893 166.0685122618381 300.34762597712955 166.0685122618381 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_42-87509" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_42" class="group firer ie-background commentable non-processed" customid="Tabs" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Button_13" class="button multiline manualfit firer click commentable non-processed" customid="HOME"   datasizewidth="92.0px" datasizeheight="31.0px" dataX="-1.0" dataY="529.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_13_0">HOME</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_14" class="button multiline manualfit firer click commentable non-processed" customid="FAVOURITES"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="91.0" dataY="529.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_14_0">FAVOURITES</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="FRIENDS"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="181.0" dataY="529.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_1_0">FRIENDS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="SETTINGS"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="271.0" dataY="529.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_2_0">SETTINGS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed" customid="Navigation bar with labels" datasizewidth="360.0px" datasizeheight="80.0px" dataX="1.2" dataY="-0.0" >\
        <div id="s-Panel_2" class="panel default firer ie-background commentable non-processed" customid="Panel 3"  datasizewidth="360.0px" datasizeheight="80.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Table_1" class="percentage table firer commentable pin hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Table"  datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="-0.0" originalwidth="360.0px" originalheight="80.0px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <table summary="">\
                        <tbody>\
                          <tr>\
                            <td id="s-Cell_1" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_2_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_1" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 1"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_2" customid="Cell 2" class="cellcontainer firer click ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_3_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_3" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 2"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_3" customid="Cell 3" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_4_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_4" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 3"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_4" customid="Cell 4" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="55.0px" datasizewidthpx="59.00000000000023" datasizeheightpx="55.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_5_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_6" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 4"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                        </tbody>\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;