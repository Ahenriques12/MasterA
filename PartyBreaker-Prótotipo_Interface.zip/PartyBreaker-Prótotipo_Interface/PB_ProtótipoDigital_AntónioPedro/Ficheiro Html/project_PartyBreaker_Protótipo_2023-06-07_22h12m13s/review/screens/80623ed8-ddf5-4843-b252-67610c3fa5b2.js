var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1686290088505.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-80623ed8-ddf5-4843-b252-67610c3fa5b2" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer commentable non-processed" alignment="left" name="Screen 4.2 - Favourites" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/80623ed8-ddf5-4843-b252-67610c3fa5b2-1686290088505.css" />\
      <div class="freeLayout">\
      <div id="s-Group_33" class="group firer ie-background commentable non-processed" customid="Grid Card" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_12" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="361.0px" datasizeheight="471.9px" datasizewidthpx="361.00000000000006" datasizeheightpx="471.93045365599505" dataX="0.2" dataY="87.9" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_12_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="image lockV firer ie-background commentable non-processed" customid="Image"   datasizewidth="361.0px" datasizeheight="349.4px" dataX="0.2" dataY="87.9" aspectRatio="0.9677419"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/c19869f0-d834-4d4b-899f-af7a21981a8e.jpg" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_20" class="richtext manualfit firer ie-background commentable non-processed" customid="Overall Rating"   datasizewidth="73.3px" datasizeheight="76.0px" dataX="260.0" dataY="449.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_20_0"><br /> 4/5</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="360.0px" datasizeheight="60.0px" datasizewidthpx="359.9999999999998" datasizeheightpx="60.0" dataX="0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="FAVOURITES"   datasizewidth="241.0px" datasizeheight="32.0px" dataX="11.0" dataY="14.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">FAVOURITES</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="71.0px" datasizeheight="64.0px" dataX="260.0" dataY="-4.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3452ab5a-a227-440a-817e-4be45d033fc7.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Dropdown_3" class="group firer ie-background commentable non-processed" customid="Dropdown menu" datasizewidth="306.0px" datasizeheight="260.0px" >\
        <div id="s-Rectangle_8" class="rectangle manualfit firer commentable hidden non-processed" customid="BG"   datasizewidth="358.8px" datasizeheight="133.5px" datasizewidthpx="358.8062953588387" datasizeheightpx="133.4999999999999" dataX="0.0" dataY="494.7" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_8_0"><br /></span><span id="rtr-s-Rectangle_8_1">Come and Dance like a true Pirate above the<br />7 seas..</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_6" class="text firer focusin commentable non-processed" customid="Input"  datasizewidth="359.1px" datasizeheight="59.0px" dataX="-0.1" dataY="435.7" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder="DESCRIPTION"/></div></div>  </div></div></div>\
        <div id="s-Path_5" class="path firer commentable non-processed" customid="dropdown arrow"   datasizewidth="10.0px" datasizeheight="5.0px" dataX="321.6" dataY="464.7"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="10.0" height="5.0" viewBox="321.56846104739725 464.70722631678507 10.0 5.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_5-80623" d="M321.56846104739725 464.70722631678507 L326.56846104739725 469.70722631678507 L331.56846104739725 464.70722631678507 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-80623" fill="#79747E" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_6" class="path firer commentable non-processed" customid="tmpSVG"   datasizewidth="18.8px" datasizeheight="16.0px" dataX="20.0" dataY="456.7"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.776453018188477" height="16.0" viewBox="19.971673125167747 456.7072263167853 18.776453018188477 16.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_6-80623" d="M29.359899986560094 458.60722629294344 C30.76813407172714 458.60722629294344 31.824309425759203 459.5072262691016 31.824309425759203 460.707226197576 C31.824309425759203 461.90722612605043 30.76813379193618 462.80722622141786 29.359899986560094 462.80722622141786 C27.951666181184017 462.80722622141786 26.89549054736099 461.90722612605043 26.89549054736099 460.7072263167853 C26.89549054736099 459.50722650752016 27.951666181184017 458.60722629294344 29.359899986560094 458.60722629294344 M29.359899986560094 467.60722593531557 C32.88048505958223 467.60722593531557 36.51842285645537 469.10722593531557 36.51842285645537 469.70722583994814 L36.51842285645537 470.80722586379 L22.201376976769332 470.80722586379 L22.201376976769332 469.7072263167853 C22.201376976769332 469.10722593531557 25.839314913537965 467.60722593531557 29.359899986560094 467.60722593531557 M29.359899986560094 456.7072263167853 C26.778137823509972 456.7072263167853 24.66578655586392 458.5072262691016 24.66578655586392 460.7072263167853 C24.66578655586392 462.907226364469 26.77813754371901 464.7072263167853 29.359899986560094 464.7072263167853 C31.941662429401184 464.7072263167853 34.05401341725627 462.907226364469 34.05401341725627 460.7072263167853 C34.05401341725627 458.5072262691016 31.941662149610224 456.7072263167853 29.359899986560094 456.7072263167853 Z M29.359899986560094 465.7072263167853 C26.191373364881986 465.7072263167853 19.971673125167747 467.0072262691016 19.971673125167747 469.7072263167853 L19.971673125167747 472.7072263167853 L38.74812684795245 472.7072263167853 L38.74812684795245 469.7072263167853 C38.74812684795245 467.00722650752016 32.52842632844724 465.7072263167853 29.359899986560094 465.7072263167853 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-80623" fill="#79747E" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Menu-minimum-width" class="group firer ie-background commentable non-processed" customid="Horizontal menu" datasizewidth="112.0px" datasizeheight="158.0px" >\
          <div id="s-Bg" class="rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="151.7px" datasizeheight="38.0px" datasizewidthpx="151.74616058993988" datasizeheightpx="37.97876547621286" dataX="99.0" dataY="583.7" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="4 Stars" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Rectangle_6" class="rectangle manualfit firer click commentable non-processed" customid="Item_4"   datasizewidth="50.6px" datasizeheight="38.0px" datasizewidthpx="50.582053529980215" datasizeheightpx="37.97876547621286" dataX="301.9" dataY="583.7" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_6_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_9" class="richtext manualfit firer click ie-background commentable non-processed" customid="Item 4"   datasizewidth="25.2px" datasizeheight="63.0px" dataX="314.6" dataY="594.7" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_9_0">Item 3</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_13" class="path firer commentable non-processed" customid="Star_outline"   datasizewidth="47.3px" datasizeheight="38.8px" dataX="305.3" dataY="579.7"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="47.250301361083984" height="38.769989013671875" viewBox="305.2634054254461 579.7111055633386 47.250301361083984 38.769989013671875" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_13-80623" d="M352.5137069265063 594.4845117194805 L335.52722340169095 593.2193857282074 L328.8885561759762 579.7111055633386 L322.24988782372645 593.2397916962631 L305.2634054254461 594.4845117194805 L318.1627378253583 604.1361986821086 L314.2882134177012 618.4810953203057 L328.8885561759762 610.8699351073586 L343.4889000607862 618.4810953203057 L339.63800049971513 604.1361986821086 L352.5137069265063 594.4845117194805 Z M328.8885561759762 607.054150192485 L320.00549951630757 611.6861436666343 L322.3680145913606 602.952692914314 L314.5244646998995 597.0759784439488 L324.87228099900005 596.3005786585394 L328.8885561759762 588.077261053137 L332.92845704443965 596.3209851130944 L343.2762733435402 597.0963848985037 L335.43272345207913 602.9730993688689 L337.79523852713214 611.7065501211893 L328.8885561759762 607.054150192485 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_13-80623" fill="#7D7D7D" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_16" class="path firer commentable non-processed" customid="Star"   datasizewidth="50.9px" datasizeheight="34.8px" dataX="301.9" dataY="579.7"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="50.88494110107422" height="34.81386947631836" viewBox="301.9316533965243 579.7111055633388 50.88494110107422 34.81386947631836" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_16-80623" d="M327.3741234355566 607.690462704908 L343.0975706961211 614.524973916534 L338.92500564611555 601.6438422414182 L352.81659347458884 592.9770212953847 L334.5234573709417 591.8593128641496 L327.3741234355566 579.7111055633388 L320.22478828698 591.8593135194344 L301.9316533965243 592.9770212953847 L315.82324213489125 601.6438422414182 L311.65067738818357 614.524973916534 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_16-80623" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="5 Stars" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Rectangle_7" class="rectangle manualfit firer click commentable non-processed" customid="Item_5"   datasizewidth="50.6px" datasizeheight="38.0px" datasizewidthpx="50.58205352997993" datasizeheightpx="37.97876547621286" dataX="251.0" dataY="583.7" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_7_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_10" class="richtext manualfit firer click ie-background commentable non-processed" customid="Item 5"   datasizewidth="25.2px" datasizeheight="63.0px" dataX="263.7" dataY="594.7" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_10_0">Item 3</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_10" class="path firer commentable non-processed" customid="Star_outline"   datasizewidth="47.3px" datasizeheight="38.8px" dataX="254.4" dataY="583.7"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="47.250301361083984" height="38.769989013671875" viewBox="254.37846534738128 583.6672269671112 47.250301361083984 38.769989013671875" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_10-80623" d="M301.6287668484415 598.4406331232532 L284.64228332362615 597.17550713198 L278.0036160979114 583.6672269671112 L271.36494774566165 597.1959131000358 L254.37846534738128 598.4406331232532 L267.2777977472935 608.0923200858813 L263.40327333963637 622.4372167240784 L278.0036160979114 614.8260565111314 L292.6039599827214 622.4372167240784 L288.75306042165033 608.0923200858813 L301.6287668484415 598.4406331232532 Z M278.0036160979114 611.0102715962577 L269.12055943824276 615.642265070407 L271.4830745132958 606.9088143180867 L263.63952462183465 601.0320998477214 L273.98734092093525 600.2567000623121 L278.0036160979114 592.0333824569097 L282.04351696637485 600.2771065168671 L292.3913332654754 601.0525063022765 L284.54778337401433 606.9292207726417 L286.91029844906734 615.662671524962 L278.0036160979114 611.0102715962577 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-80623" fill="#7D7D7D" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_9" class="path firer commentable non-processed" customid="Star"   datasizewidth="50.9px" datasizeheight="34.8px" dataX="251.0" dataY="583.7"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="50.88494110107422" height="34.81386947631836" viewBox="251.04671331846015 583.6672269671114 50.88494110107422 34.81386947631836" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_9-80623" d="M276.48918335749227 611.6465841086805 L292.21263061805666 618.4810953203065 L288.04006556805115 605.5999636451907 L301.9316533965244 596.9331426991572 L283.63851729287734 595.8154342679222 L276.48918335749227 583.6672269671114 L269.3398482089157 595.8154349232069 L251.04671331846015 596.9331426991572 L264.938302056827 605.5999636451907 L260.7657373101194 618.4810953203065 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-80623" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="3 Stars" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Item_3" class="rectangle manualfit firer click commentable non-processed" customid="Item_3"   datasizewidth="50.6px" datasizeheight="38.0px" datasizewidthpx="50.582053529980186" datasizeheightpx="37.97876547621286" dataX="200.2" dataY="583.7" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Item_3_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_6" class="richtext manualfit firer click ie-background commentable non-processed" customid="Item 3"   datasizewidth="25.2px" datasizeheight="63.0px" dataX="212.9" dataY="594.7" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_6_0">Item 3</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_12" class="path firer commentable non-processed" customid="Star_outline"   datasizewidth="47.3px" datasizeheight="38.8px" dataX="203.5" dataY="583.7"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="47.250301361083984" height="38.769989013671875" viewBox="203.49352526931784 583.6672269671112 47.250301361083984 38.769989013671875" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_12-80623" d="M250.74382677037806 598.4406331232532 L233.7573432455627 597.17550713198 L227.11867601984795 583.6672269671112 L220.48000766759822 597.1959131000358 L203.49352526931784 598.4406331232532 L216.39285766923007 608.0923200858813 L212.51833326157293 622.4372167240784 L227.11867601984795 614.8260565111314 L241.71901990465796 622.4372167240784 L237.8681203435869 608.0923200858813 L250.74382677037806 598.4406331232532 Z M227.11867601984795 611.0102715962577 L218.23561936017933 615.642265070407 L220.59813443523234 606.9088143180867 L212.75458454377124 601.0320998477214 L223.10240084287182 600.2567000623121 L227.11867601984795 592.0333824569097 L231.1585768883114 600.2771065168671 L241.506393187412 601.0525063022765 L233.6628432959509 606.9292207726417 L236.0253583710039 615.662671524962 L227.11867601984795 611.0102715962577 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_12-80623" fill="#7D7D7D" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_8" class="path firer commentable non-processed" customid="Star"   datasizewidth="50.9px" datasizeheight="34.8px" dataX="200.2" dataY="583.7"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="50.88494110107422" height="34.81386947631836" viewBox="200.16177324039626 583.6672269671114 50.88494110107422 34.81386947631836" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_8-80623" d="M225.60424327942837 611.6465841086805 L241.32769053999277 618.4810953203065 L237.15512548998726 605.5999636451907 L251.04671331846046 596.9331426991572 L232.7535772148134 595.8154342679222 L225.60424327942837 583.6672269671114 L218.4549081308518 595.8154349232069 L200.16177324039626 596.9331426991572 L214.05336197876312 605.5999636451907 L209.88079723205547 618.4810953203065 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-80623" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="2 Stars" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Item_2" class="rectangle manualfit firer click commentable non-processed" customid="Item_2"   datasizewidth="50.6px" datasizeheight="38.0px" datasizewidthpx="50.58205352997996" datasizeheightpx="37.97876547621286" dataX="149.6" dataY="583.7" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Item_2_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_7" class="richtext manualfit firer click ie-background commentable non-processed" customid="Item 2"   datasizewidth="25.2px" datasizeheight="63.0px" dataX="162.3" dataY="594.7" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_7_0">Item 2</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_14" class="path firer commentable non-processed" customid="Star_outline"   datasizewidth="47.3px" datasizeheight="38.8px" dataX="152.9" dataY="583.7"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="47.250301361083984" height="38.769989013671875" viewBox="152.9114717393379 583.6672269671112 47.250301361083984 38.769989013671875" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_14-80623" d="M200.16177324039813 598.4406331232532 L183.17528971558278 597.17550713198 L176.53662248986802 583.6672269671112 L169.89795413761829 597.1959131000358 L152.9114717393379 598.4406331232532 L165.81080413925014 608.0923200858813 L161.936279731593 622.4372167240784 L176.53662248986802 614.8260565111314 L191.13696637467802 622.4372167240784 L187.28606681360696 608.0923200858813 L200.16177324039813 598.4406331232532 Z M176.53662248986802 611.0102715962577 L167.6535658301994 615.642265070407 L170.0160809052524 606.9088143180867 L162.1725310137913 601.0320998477214 L172.5203473128919 600.2567000623121 L176.53662248986802 592.0333824569097 L180.57652335833146 600.2771065168671 L190.92433965743206 601.0525063022765 L183.08078976597096 606.9292207726417 L185.44330484102397 615.662671524962 L176.53662248986802 611.0102715962577 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-80623" fill="#7D7D7D" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_7" class="path firer commentable non-processed" customid="Star"   datasizewidth="50.9px" datasizeheight="34.8px" dataX="149.6" dataY="583.7"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="50.88494110107422" height="34.81386947631836" viewBox="149.57971971041633 583.6672269671114 50.88494110107422 34.81386947631836" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_7-80623" d="M175.02218974944847 611.6465841086805 L190.7456370100129 618.4810953203065 L186.57307196000735 605.5999636451907 L200.4646597884806 596.9331426991572 L182.17152368483352 595.8154342679222 L175.02218974944847 583.6672269671114 L167.8728546008719 595.8154349232069 L149.57971971041633 596.9331426991572 L163.4713084487832 605.5999636451907 L159.29874370207554 618.4810953203065 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-80623" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="1 Star" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Item_1" class="rectangle manualfit firer click commentable non-processed" customid="Item_1"   datasizewidth="50.6px" datasizeheight="38.0px" datasizewidthpx="50.582053529980215" datasizeheightpx="37.97876547621286" dataX="99.0" dataY="583.7" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Item_1_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_8" class="richtext manualfit firer click ie-background commentable non-processed" customid="Item 1"   datasizewidth="25.2px" datasizeheight="63.0px" dataX="111.7" dataY="594.7" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_8_0">Item 1</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_15" class="path firer commentable non-processed" customid="Star_outline"   datasizewidth="47.3px" datasizeheight="38.8px" dataX="102.3" dataY="583.7"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="47.250301361083984" height="38.769989013671875" viewBox="102.32941820935812 583.6672269671112 47.250301361083984 38.769989013671875" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_15-80623" d="M149.57971971041806 598.4406331232532 L132.5932361856028 597.17550713198 L125.95456895988809 583.6672269671112 L119.3159006076384 597.1959131000358 L102.32941820935812 598.4406331232532 L115.22875060927028 608.0923200858813 L111.35422620161316 622.4372167240784 L125.95456895988809 614.8260565111314 L140.55491284469798 622.4372167240784 L136.70401328362695 608.0923200858813 L149.57971971041806 598.4406331232532 Z M125.95456895988809 611.0102715962577 L117.07151230021952 615.642265070407 L119.43402737527252 606.9088143180867 L111.59047748381147 601.0320998477214 L121.93829378291198 600.2567000623121 L125.95456895988809 592.0333824569097 L129.9944698283515 600.2771065168671 L140.34228612745204 601.0525063022765 L132.49873623599098 606.9292207726417 L134.861251311044 615.662671524962 L125.95456895988809 611.0102715962577 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-80623" fill="#7D7D7D" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_11" class="path firer commentable non-processed" customid="Star"   datasizewidth="50.9px" datasizeheight="34.8px" dataX="99.0" dataY="583.7"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="50.88494110107422" height="34.81386947631836" viewBox="98.99766618043729 583.6672269671114 50.88494110107422 34.81386947631836" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_11-80623" d="M124.44013621946944 611.6465841086805 L140.16358348003385 618.4810953203065 L135.9910184300283 605.5999636451907 L149.88260625850154 596.9331426991572 L131.5894701548545 595.8154342679222 L124.44013621946944 583.6672269671114 L117.29080107089287 595.8154349232069 L98.99766618043729 596.9331426991572 L112.88925491880416 605.5999636451907 L108.71669017209652 618.4810953203065 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-80623" fill="#FEE94E" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed" customid="Navigation bar with labels" datasizewidth="360.0px" datasizeheight="63.0px" dataX="1.2" dataY="0.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel 3"  datasizewidth="360.0px" datasizeheight="63.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Table_1" class="percentage table firer commentable pin hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Table"  datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="-0.0" originalwidth="360.0px" originalheight="80.0px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <table summary="">\
                        <tbody>\
                          <tr>\
                            <td id="s-Cell_1" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_1_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_1" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 1"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_2" customid="Cell 2" class="cellcontainer firer click ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_2_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_2" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 2"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_3" customid="Cell 3" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_3_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_3" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 3"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_4" customid="Cell 4" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="55.0px" datasizewidthpx="59.00000000000023" datasizeheightpx="55.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_4_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_4" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 4"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                        </tbody>\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Tabs" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="HOME"   datasizewidth="92.0px" datasizeheight="31.0px" dataX="-0.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_5_0">HOME</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="FAVOURITES"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="92.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_6_0">FAVOURITES</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_7" class="button multiline manualfit firer click commentable non-processed" customid="FRIENDS"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="182.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_7_0">FRIENDS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_8" class="button multiline manualfit firer click commentable non-processed" customid="SETTINGS"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="272.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_8_0">SETTINGS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="BLACKSHIP"   datasizewidth="123.5px" datasizeheight="25.0px" dataX="11.0" dataY="497.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">BLACKSHIP</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;