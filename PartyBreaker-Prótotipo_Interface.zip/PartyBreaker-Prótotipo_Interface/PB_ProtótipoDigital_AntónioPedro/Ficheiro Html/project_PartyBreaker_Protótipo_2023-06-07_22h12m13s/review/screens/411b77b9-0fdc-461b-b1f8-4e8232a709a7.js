var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1686290088505.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-411b77b9-0fdc-461b-b1f8-4e8232a709a7" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer commentable non-processed" alignment="left" name="Screen 4 - Favourites" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/411b77b9-0fdc-461b-b1f8-4e8232a709a7-1686290088505.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="360.0px" datasizeheight="60.0px" datasizewidthpx="359.9999999999998" datasizeheightpx="60.0" dataX="0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="71.0px" datasizeheight="64.0px" dataX="260.0" dataY="-4.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3452ab5a-a227-440a-817e-4be45d033fc7.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="FAVOURITES"   datasizewidth="241.0px" datasizeheight="32.0px" dataX="11.0" dataY="14.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">FAVOURITES</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_51" class="group firer ie-background commentable non-processed" customid="Grid" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_40" class="group firer ie-background commentable non-processed" customid="Grid Card" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_20" class="rectangle manualfit firer click commentable non-processed" customid="BG"   datasizewidth="156.0px" datasizeheight="215.0px" datasizewidthpx="156.0" datasizeheightpx="215.0" dataX="10.0" dataY="82.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_20_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_34" class="richtext manualfit firer click ie-background commentable non-processed" customid="BLACKSHIP"   datasizewidth="112.0px" datasizeheight="42.0px" dataX="32.0" dataY="223.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_34_0">BLACKSHIP</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_36" class="richtext manualfit firer click ie-background commentable non-processed" customid="Come and Dance likea true"   datasizewidth="141.0px" datasizeheight="64.0px" dataX="17.5" dataY="244.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_36_0">Come and Dance like<br />a true Pirate above the<br />7 seas..</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_5" class="image lockV firer click ie-background commentable non-processed" customid="Image"   datasizewidth="156.0px" datasizeheight="151.0px" dataX="10.0" dataY="82.0" aspectRatio="0.96774197"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/36cc641d-6c24-418c-9345-3805e88a6c5e.jpg" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_42" class="group firer ie-background commentable non-processed" customid="Grid Card" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_24" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="156.0px" datasizeheight="215.0px" datasizewidthpx="156.0" datasizeheightpx="215.0" dataX="177.0" dataY="77.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_24_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_37" class="richtext manualfit firer ie-background commentable non-processed" customid="CLUBHOUSE"   datasizewidth="102.0px" datasizeheight="63.0px" dataX="204.0" dataY="206.5" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_37_0">CLUBHOUSE</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_39" class="richtext manualfit firer ie-background commentable non-processed" customid="What happens In the Club."   datasizewidth="149.0px" datasizeheight="45.0px" dataX="180.5" dataY="247.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_39_0">What happens In<br /> the Club...Stays In The<br />Club...</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_10" class="image lockV firer ie-background commentable non-processed" customid="Image"   datasizewidth="156.0px" datasizeheight="151.0px" dataX="177.0" dataY="77.0" aspectRatio="0.96774197"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/1d48b3a2-e09e-4f69-8fe3-e1928db670c1.jpg" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_43" class="group firer ie-background commentable non-processed" customid="Grid Card" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_25" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="156.0px" datasizeheight="215.0px" datasizewidthpx="156.0" datasizeheightpx="215.0" dataX="10.0" dataY="308.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_25_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_40" class="richtext manualfit firer ie-background commentable non-processed" customid="BAR K"   datasizewidth="102.0px" datasizeheight="21.0px" dataX="22.0" dataY="459.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_40_0">BAR K</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_41" class="richtext manualfit firer ie-background commentable non-processed" customid="Enjoy the best drinksand "   datasizewidth="156.0px" datasizeheight="83.9px" dataX="10.0" dataY="459.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_41_0">Enjoy the best drinks<br />and snaks directly from<br /> Italy to Portugal...</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_11" class="image lockV firer ie-background commentable non-processed" customid="Image"   datasizewidth="156.0px" datasizeheight="151.0px" dataX="10.0" dataY="308.0" aspectRatio="0.96774197"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/e083e428-b379-498c-91e5-466e8729338e.jpg" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_44" class="group firer ie-background commentable non-processed" customid="Grid Card" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_26" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="156.0px" datasizeheight="215.0px" datasizewidthpx="156.0" datasizeheightpx="215.0" dataX="177.0" dataY="308.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_26_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_42" class="richtext manualfit firer ie-background commentable non-processed" customid="YELLOW FLASH"   datasizewidth="130.0px" datasizeheight="51.0px" dataX="185.0" dataY="443.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_42_0">YELLOW FLASH</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_43" class="richtext manualfit firer ie-background commentable non-processed" customid="A Win Is a Win,even if it"   datasizewidth="156.0px" datasizeheight="105.0px" dataX="177.0" dataY="453.5" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_43_0">A Win Is a Win,even if <br />its done at the speed of <br />Light... come play with us<br /><br /></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_6" class="image lockV firer ie-background commentable non-processed" customid="Image"   datasizewidth="156.0px" datasizeheight="151.0px" dataX="177.0" dataY="308.0" aspectRatio="0.96774197"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/add315c0-81ff-407f-b1df-ef6ba3d6fec1.jpg" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
        <div id="s-Path_27" class="path firer commentable non-processed" customid="dropdown arrow"   datasizewidth="8.0px" datasizeheight="4.0px" dataX="325.0" dataY="77.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="8.0" height="4.0" viewBox="325.0 77.0 8.0 4.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_27-411b7" d="M325.0 77.0 L329.0 81.0 L333.0 77.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_27-411b7" fill="#313033" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_50" class="richtext manualfit firer ie-background commentable non-processed" customid="Your Most Liked Places"   datasizewidth="259.3px" datasizeheight="87.0px" dataX="10.0" dataY="30.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_50_0">Your Most Liked Places</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed" customid="Navigation bar with labels" datasizewidth="360.0px" datasizeheight="80.0px" dataX="1.2" dataY="-0.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel 3"  datasizewidth="360.0px" datasizeheight="80.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Table_1" class="percentage table firer commentable pin hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Table"  datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="-0.0" originalwidth="360.0px" originalheight="80.0px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <table summary="">\
                        <tbody>\
                          <tr>\
                            <td id="s-Cell_1" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_2_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_1" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 1"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_2" customid="Cell 2" class="cellcontainer firer click ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_3_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_2" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 2"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_3" customid="Cell 3" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_4_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_3" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 3"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_4" customid="Cell 4" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="55.0px" datasizewidthpx="59.00000000000023" datasizeheightpx="55.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_5_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_4" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 4"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                        </tbody>\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Tabs" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="HOME"   datasizewidth="92.0px" datasizeheight="31.0px" dataX="-1.0" dataY="529.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_1_0">HOME</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="FAVOURITES"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="91.0" dataY="529.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_2_0">FAVOURITES</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="FRIENDS"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="181.0" dataY="529.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_3_0">FRIENDS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="SETTINGS"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="271.0" dataY="529.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_4_0">SETTINGS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;