var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1686290088505.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-de3fa695-1708-4fae-a804-a695e8b3ac17" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 5 - Friends" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/de3fa695-1708-4fae-a804-a695e8b3ac17-1686290088505.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="360.0px" datasizeheight="60.0px" datasizewidthpx="359.9999999999998" datasizeheightpx="60.0" dataX="0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="360.0px" datasizeheight="50.0px" datasizewidthpx="359.9999999999998" datasizeheightpx="50.000000000000114" dataX="0.0" dataY="60.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="FRIENDS"   datasizewidth="241.0px" datasizeheight="32.0px" dataX="11.0" dataY="14.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">FRIENDS</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="71.0px" datasizeheight="64.0px" dataX="260.0" dataY="-4.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e54ad235-9bcb-4661-b34e-dd92bb759a4e.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Life Is Better In a Multi"   datasizewidth="247.2px" datasizeheight="18.0px" dataX="56.4" dataY="76.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Life Is Better In a Multiplayer Mode</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_51" class="group firer ie-background commentable non-processed" customid="List" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Path_200" class="path firer ie-background commentable non-processed" customid="Divider"   datasizewidth="197.4px" datasizeheight="2.0px" dataX="1.1" dataY="169.2"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="197.94619750976562" height="1.5" viewBox="1.086923076922659 169.24027168681147 197.94619750976562 1.5" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_200-de3fa" d="M1.836923076922659 169.99027168681147 L198.2831279145507 169.99027168681147 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_200-de3fa" fill="none" stroke-width="0.5" stroke="#79747E" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_40" class="group firer ie-background commentable non-processed" customid="Item 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="shapewrapper-s-Ellipse_7" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_7 non-processed"   datasizewidth="27.6px" datasizeheight="43.1px" datasizewidthpx="27.55384615384625" datasizeheightpx="43.121468669644116" dataX="-0.0" dataY="180.5" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_7" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_7)">\
                              <ellipse id="s-Ellipse_7" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse" cx="13.776923076923126" cy="21.560734334822058" rx="13.776923076923126" ry="21.560734334822058">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_7" class="clipPath">\
                              <ellipse cx="13.776923076923126" cy="21.560734334822058" rx="13.776923076923126" ry="21.560734334822058">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_7" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_7_0">F</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Paragraph_57" class="richtext manualfit firer ie-background commentable non-processed" customid="Felix"   datasizewidth="70.2px" datasizeheight="43.6px" dataX="36.1" dataY="179.1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_57_0">Felix<br /><br /></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_207" class="path firer ie-background commentable non-processed" customid="Path"   datasizewidth="14.5px" datasizeheight="13.0px" dataX="181.0" dataY="193.4"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="15.000091552734375" height="13.000041961669922" viewBox="180.98652141864454 193.3785108597887 15.000091552734375 13.000041961669922" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_207-de3fa" d="M183.22756450946486 204.87855282145856 L188.48656719501173 195.86315288859728 L193.7455698805586 204.87855282145856 L183.22756450946486 204.87855282145856 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_207-de3fa" fill="none" stroke-width="2.0" stroke="#49454F" stroke-linecap="butt"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Path_201" class="path firer ie-background commentable non-processed" customid="Divider"   datasizewidth="197.4px" datasizeheight="2.0px" dataX="1.1" dataY="232.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="197.94619750976562" height="1.5" viewBox="1.086923076922659 232.48509240228964 197.94619750976562 1.5" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_201-de3fa" d="M1.836923076922659 233.23509240228964 L198.2831279145507 233.23509240228964 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_201-de3fa" fill="none" stroke-width="0.5" stroke="#79747E" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_41" class="group firer ie-background commentable non-processed" customid="Item 3" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="shapewrapper-s-Ellipse_6" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="27.6px" datasizeheight="43.1px" datasizewidthpx="27.55384615384625" datasizeheightpx="43.12146866964406" dataX="-0.0" dataY="242.8" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_6)">\
                              <ellipse id="s-Ellipse_6" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse" cx="13.776923076923126" cy="21.56073433482203" rx="13.776923076923126" ry="21.56073433482203">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                              <ellipse cx="13.776923076923126" cy="21.56073433482203" rx="13.776923076923126" ry="21.56073433482203">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_6" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_6_0">L</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Paragraph_58" class="richtext manualfit firer ie-background commentable non-processed" customid="Laura"   datasizewidth="62.6px" datasizeheight="43.6px" dataX="36.1" dataY="241.4" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_58_0">Laura</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_208" class="path firer ie-background commentable non-processed" customid="Path"   datasizewidth="14.5px" datasizeheight="13.0px" dataX="181.0" dataY="256.6"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="15.000091552734375" height="13.000041961669922" viewBox="180.98652141864454 256.62333157526723 15.000091552734375 13.000041961669922" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_208-de3fa" d="M183.22756450946486 268.12337353693715 L188.48656719501173 259.1079736040758 L193.7455698805586 268.12337353693715 L183.22756450946486 268.12337353693715 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_208-de3fa" fill="none" stroke-width="2.0" stroke="#49454F" stroke-linecap="butt"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Path_202" class="path firer ie-background commentable non-processed" customid="Divider"   datasizewidth="197.4px" datasizeheight="2.0px" dataX="1.1" dataY="293.8"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="197.94619750976562" height="1.5" viewBox="1.086923076922659 293.8134033991165 197.94619750976562 1.5" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_202-de3fa" d="M1.836923076922659 294.5634033991165 L198.2831279145507 294.5634033991165 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_202-de3fa" fill="none" stroke-width="0.5" stroke="#79747E" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_54" class="group firer ie-background commentable non-processed" customid="item 4" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_59" class="richtext manualfit firer ie-background commentable non-processed" customid="Maria"   datasizewidth="56.8px" datasizeheight="43.6px" dataX="36.1" dataY="303.7" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_59_0">Maria</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_9" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_9 non-processed"   datasizewidth="27.6px" datasizeheight="43.1px" datasizewidthpx="27.55384615384625" datasizeheightpx="43.12146866964417" dataX="-0.0" dataY="305.1" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_9" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_9)">\
                              <ellipse id="s-Ellipse_9" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse" cx="13.776923076923126" cy="21.560734334822087" rx="13.776923076923126" ry="21.560734334822087">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_9" class="clipPath">\
                              <ellipse cx="13.776923076923126" cy="21.560734334822087" rx="13.776923076923126" ry="21.560734334822087">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_9" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_9_0">M</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Path_209" class="path firer ie-background commentable non-processed" customid="Path"   datasizewidth="14.5px" datasizeheight="13.0px" dataX="181.0" dataY="319.9"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="15.000091552734375" height="13.000041961669922" viewBox="180.98652141864454 319.8681522907454 15.000091552734375 13.000041961669922" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_209-de3fa" d="M183.22756450946486 331.3681942524152 L188.48656719501173 322.352794319554 L193.7455698805586 331.3681942524152 L183.22756450946486 331.3681942524152 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_209-de3fa" fill="none" stroke-width="2.0" stroke="#49454F" stroke-linecap="butt"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Path_203" class="path firer ie-background commentable non-processed" customid="Divider"   datasizewidth="197.4px" datasizeheight="2.0px" dataX="1.1" dataY="358.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="197.94619750976562" height="1.5" viewBox="1.086923076922659 358.0164789739204 197.94619750976562 1.5" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_203-de3fa" d="M1.836923076922659 358.7664789739204 L198.2831279145507 358.7664789739204 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_203-de3fa" fill="none" stroke-width="0.5" stroke="#79747E" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_42" class="group firer ie-background commentable non-processed" customid="Item 5" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="shapewrapper-s-Ellipse_10" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_10 non-processed"   datasizewidth="27.6px" datasizeheight="43.1px" datasizewidthpx="27.55384615384625" datasizeheightpx="43.12146866964406" dataX="-0.0" dataY="367.4" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_10" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_10)">\
                              <ellipse id="s-Ellipse_10" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse" cx="13.776923076923126" cy="21.56073433482203" rx="13.776923076923126" ry="21.56073433482203">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_10" class="clipPath">\
                              <ellipse cx="13.776923076923126" cy="21.56073433482203" rx="13.776923076923126" ry="21.56073433482203">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_10" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_10_0">T</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Paragraph_61" class="richtext manualfit firer ie-background commentable non-processed" customid="Tom"   datasizewidth="46.2px" datasizeheight="43.6px" dataX="36.1" dataY="366.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_61_0">Tom</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_210" class="path firer ie-background commentable non-processed" customid="Path"   datasizewidth="14.5px" datasizeheight="13.0px" dataX="181.0" dataY="383.1"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="15.000091552734375" height="13.000041961669922" viewBox="180.98652141864454 383.11297300622385 15.000091552734375 13.000041961669922" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_210-de3fa" d="M183.22756450946486 394.61301496789366 L188.48656719501173 385.59761503503245 L193.7455698805586 394.61301496789366 L183.22756450946486 394.61301496789366 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_210-de3fa" fill="none" stroke-width="2.0" stroke="#49454F" stroke-linecap="butt"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Path_204" class="path firer ie-background commentable non-processed" customid="Divider"   datasizewidth="197.4px" datasizeheight="2.0px" dataX="1.1" dataY="421.3"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="197.94619750976562" height="1.5" viewBox="1.086923076922659 421.2612996893978 197.94619750976562 1.5" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_204-de3fa" d="M1.836923076922659 422.0112996893978 L198.2831279145507 422.0112996893978 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_204-de3fa" fill="none" stroke-width="0.5" stroke="#79747E" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_43" class="group firer ie-background commentable non-processed" customid="Item 6" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="shapewrapper-s-Ellipse_11" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_11 non-processed"   datasizewidth="27.6px" datasizeheight="43.1px" datasizewidthpx="27.55384615384625" datasizeheightpx="43.12146866964417" dataX="-0.0" dataY="429.7" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_11" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_11)">\
                              <ellipse id="s-Ellipse_11" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse" cx="13.776923076923126" cy="21.560734334822087" rx="13.776923076923126" ry="21.560734334822087">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_11" class="clipPath">\
                              <ellipse cx="13.776923076923126" cy="21.560734334822087" rx="13.776923076923126" ry="21.560734334822087">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_11" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_11_0">S</span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Paragraph_64" class="richtext manualfit firer ie-background commentable non-processed" customid="Sandra"   datasizewidth="72.4px" datasizeheight="43.6px" dataX="36.1" dataY="428.3" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_64_0">Sandra</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_211" class="path firer ie-background commentable non-processed" customid="Path"   datasizewidth="14.5px" datasizeheight="13.0px" dataX="181.0" dataY="447.3"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="15.000091552734375" height="13.000041961669922" viewBox="180.98652141864454 447.31604858102685 15.000091552734375 13.000041961669922" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_211-de3fa" d="M183.22756450946486 458.81609054269677 L188.48656719501173 449.80069060983544 L193.7455698805586 458.81609054269677 L183.22756450946486 458.81609054269677 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_211-de3fa" fill="none" stroke-width="2.0" stroke="#49454F" stroke-linecap="butt"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Path_205" class="path firer ie-background commentable non-processed" customid="Divider"   datasizewidth="197.4px" datasizeheight="2.0px" dataX="1.1" dataY="482.6"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="197.94619750976562" height="1.5" viewBox="1.086923076922659 482.5896106862255 197.94619750976562 1.5" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_205-de3fa" d="M1.836923076922659 483.3396106862255 L198.2831279145507 483.3396106862255 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_205-de3fa" fill="none" stroke-width="0.5" stroke="#79747E" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Path_119" class="path firer commentable non-processed" customid="Arrow Upward"   datasizewidth="49.0px" datasizeheight="39.0px" dataX="7.4" dataY="120.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="49.0" height="39.0" viewBox="7.386718750000767 120.0 49.0 39.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_119-de3fa" d="M56.386718750000256 139.50000000000017 L52.068593852222264 136.06312508136048 L34.94921875000048 149.66437518596675 L34.94921875000048 120.0 L28.82421875000054 120.0 L28.82421875000054 149.66437518596675 L11.735468983650929 136.03874981403365 L7.386718750000767 139.50000000000017 L31.88671875000051 159.00000000000034 L56.386718750000256 139.50000000000017 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_119-de3fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="CHOSE YOUR PARTNER"   datasizewidth="112.0px" datasizeheight="36.0px" dataX="68.0" dataY="121.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">CHOSE YOUR <br />PARTNER</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="150.0px" datasizeheight="441.0px" dataX="210.0" dataY="107.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/d6baa7ca-3b87-4d42-b568-1fdf903a564f.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="image firer click ie-background commentable non-processed" customid="Image"   datasizewidth="47.0px" datasizeheight="50.0px" dataX="84.5" dataY="498.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/52071f75-dda0-44ce-8258-a983af2be32c.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer click ie-background commentable non-processed" customid="Image"   datasizewidth="47.0px" datasizeheight="50.0px" dataX="156.5" dataY="498.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/f87c9538-5973-4432-88b6-757b7289acd5.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed" customid="Navigation bar with labels" datasizewidth="360.0px" datasizeheight="63.0px" dataX="1.2" dataY="0.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel 3"  datasizewidth="360.0px" datasizeheight="63.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Table_1" class="percentage table firer commentable pin hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Table"  datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="-0.0" originalwidth="360.0px" originalheight="80.0px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <table summary="">\
                        <tbody>\
                          <tr>\
                            <td id="s-Cell_1" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_3_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_1" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 1"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_2" customid="Cell 2" class="cellcontainer firer click ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_4_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_2" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 2"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_3" customid="Cell 3" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="49.0px" datasizewidthpx="59.0" datasizeheightpx="49.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_5_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_3" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 3"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                            <td id="s-Cell_4" customid="Cell 4" class="cellcontainer firer ie-background non-processed"    datasizewidth="90.0px" datasizeheight="80.0px" dataX="0.0" dataY="0.0" originalwidth="89.99999999999999px" originalheight="79.99999999999999px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_6" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="59.0px" datasizeheight="55.0px" datasizewidthpx="59.00000000000023" datasizeheightpx="55.02999999999997" dataX="15.0" dataY="13.0" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_6_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Hotspot_4" class="percentage imagemap firer click ie-background commentable non-processed-percentage non-processed" customid="Hotspot 4"   datasizewidth="100.0%" datasizeheight="80.0px" dataX="0.0" dataY="0.0"  >\
                                        <div class="clickableSpot"></div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                        </tbody>\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Tabs" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="HOME"   datasizewidth="92.0px" datasizeheight="31.0px" dataX="-0.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_1_0">HOME</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="FAVOURITES"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="92.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_2_0">FAVOURITES</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="FRIENDS"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="182.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_3_0">FRIENDS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="SETTINGS"   datasizewidth="90.0px" datasizeheight="31.0px" dataX="272.0" dataY="547.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_4_0">SETTINGS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;