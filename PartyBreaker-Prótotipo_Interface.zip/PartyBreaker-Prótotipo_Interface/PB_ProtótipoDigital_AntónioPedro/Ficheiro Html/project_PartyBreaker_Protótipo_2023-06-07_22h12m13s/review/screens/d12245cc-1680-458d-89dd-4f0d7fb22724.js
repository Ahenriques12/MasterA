var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1686290088505.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1686290088505.css" />\
      <div class="freeLayout">\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="368.0px" datasizeheight="640.0px" dataX="-8.0" dataY="-0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e1041382-e7e4-41e8-b8ff-494091f26a28.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="LOGIN"   datasizewidth="193.0px" datasizeheight="53.0px" dataX="73.0" dataY="510.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">LOGIN</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="30.0" dataY="75.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/64d38234-78e6-4ff2-b5cf-411f9eb4fd76.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="230.0" dataY="75.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/525c142b-59f1-4948-ab47-1288158d90a5.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="30.0" dataY="292.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/bc4a0889-7312-4e8a-bcbe-46e6fc16b278.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="230.0" dataY="292.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/46e47f57-7565-42da-a1b1-5828b7d626c8.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="PARTYBREAKER"   datasizewidth="193.0px" datasizeheight="86.0px" dataX="73.0" dataY="415.3" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">PARTY<br />BREAKER</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer commentable non-processed" customid="No Account?"   datasizewidth="91.6px" datasizeheight="18.0px" dataX="77.9" dataY="604.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">No Account?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Create One"   datasizewidth="155.0px" datasizeheight="17.0px" dataX="180.0" dataY="605.4" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Create One</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;