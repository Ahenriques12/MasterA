(function(window, undefined) {
  var dictionary = {
    "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277": "Screen 6.4 - Language (Portuguese)",
    "411b77b9-0fdc-461b-b1f8-4e8232a709a7": "Screen 4 - Favourites",
    "875096b0-3993-43a9-9643-053c9785c00d": "Screen 3 - Main Menu",
    "2eae7366-3a01-4b30-8e46-12da7958a706": "Screen 6 - Settings",
    "338bacdb-a63d-468d-a909-9271740becd8": "Screen 5.3 Friends",
    "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5": "Screen 6.4 - Language",
    "80623ed8-ddf5-4843-b252-67610c3fa5b2": "Screen 4.2 - Favourites",
    "fe0140cd-a3a3-4d96-8def-0ed0454203b8": "Screen 2 - Login",
    "622d7dd8-ad38-42cc-83d1-7bc2f77c922b": "Screen 6.3 - Notifications",
    "30d2e1f4-00c7-42cf-b058-9e8845b5a61b": "Screen 5.2 Friends",
    "de3fa695-1708-4fae-a804-a695e8b3ac17": "Screen 5 - Friends",
    "64e355e8-cbf2-4945-b8e9-0f2807aec862": "Screen 6.2 - Dark Mode",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Screen 1",
    "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632": "Screen 6.1 - Account",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);