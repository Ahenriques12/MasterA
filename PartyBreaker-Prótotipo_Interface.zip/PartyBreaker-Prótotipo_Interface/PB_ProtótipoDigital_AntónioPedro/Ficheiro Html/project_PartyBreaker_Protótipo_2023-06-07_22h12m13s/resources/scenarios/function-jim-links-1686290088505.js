(function(window, undefined) {

  var jimLinks = {
    "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277" : {
      "Button_2" : [
        "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"
      ],
      "Button_5" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ],
      "Button_6" : [
        "411b77b9-0fdc-461b-b1f8-4e8232a709a7"
      ],
      "Button_7" : [
        "de3fa695-1708-4fae-a804-a695e8b3ac17"
      ],
      "Button_8" : [
        "2eae7366-3a01-4b30-8e46-12da7958a706"
      ]
    },
    "411b77b9-0fdc-461b-b1f8-4e8232a709a7" : {
      "Rectangle_20" : [
        "80623ed8-ddf5-4843-b252-67610c3fa5b2"
      ],
      "Paragraph_34" : [
        "80623ed8-ddf5-4843-b252-67610c3fa5b2"
      ],
      "Paragraph_36" : [
        "80623ed8-ddf5-4843-b252-67610c3fa5b2"
      ],
      "Image_5" : [
        "80623ed8-ddf5-4843-b252-67610c3fa5b2"
      ],
      "Button_1" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ],
      "Button_2" : [
        "411b77b9-0fdc-461b-b1f8-4e8232a709a7"
      ],
      "Button_3" : [
        "de3fa695-1708-4fae-a804-a695e8b3ac17"
      ],
      "Button_4" : [
        "2eae7366-3a01-4b30-8e46-12da7958a706"
      ]
    },
    "875096b0-3993-43a9-9643-053c9785c00d" : {
      "Button_13" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ],
      "Button_14" : [
        "411b77b9-0fdc-461b-b1f8-4e8232a709a7"
      ],
      "Button_1" : [
        "de3fa695-1708-4fae-a804-a695e8b3ac17"
      ],
      "Button_2" : [
        "2eae7366-3a01-4b30-8e46-12da7958a706"
      ]
    },
    "2eae7366-3a01-4b30-8e46-12da7958a706" : {
      "Button_5" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ],
      "Button_6" : [
        "411b77b9-0fdc-461b-b1f8-4e8232a709a7"
      ],
      "Button_7" : [
        "de3fa695-1708-4fae-a804-a695e8b3ac17"
      ],
      "Button_8" : [
        "2eae7366-3a01-4b30-8e46-12da7958a706"
      ]
    },
    "338bacdb-a63d-468d-a909-9271740becd8" : {
      "Button_1" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ]
    },
    "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5" : {
      "Button_3" : [
        "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"
      ],
      "Button_5" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ],
      "Button_6" : [
        "411b77b9-0fdc-461b-b1f8-4e8232a709a7"
      ],
      "Button_7" : [
        "de3fa695-1708-4fae-a804-a695e8b3ac17"
      ],
      "Button_8" : [
        "2eae7366-3a01-4b30-8e46-12da7958a706"
      ]
    },
    "80623ed8-ddf5-4843-b252-67610c3fa5b2" : {
      "Button_5" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ],
      "Button_6" : [
        "411b77b9-0fdc-461b-b1f8-4e8232a709a7"
      ],
      "Button_7" : [
        "de3fa695-1708-4fae-a804-a695e8b3ac17"
      ],
      "Button_8" : [
        "2eae7366-3a01-4b30-8e46-12da7958a706"
      ]
    },
    "fe0140cd-a3a3-4d96-8def-0ed0454203b8" : {
      "Button_2" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ]
    },
    "622d7dd8-ad38-42cc-83d1-7bc2f77c922b" : {
      "Button_1" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ],
      "Button_2" : [
        "411b77b9-0fdc-461b-b1f8-4e8232a709a7"
      ],
      "Button_3" : [
        "de3fa695-1708-4fae-a804-a695e8b3ac17"
      ],
      "Button_4" : [
        "2eae7366-3a01-4b30-8e46-12da7958a706"
      ]
    },
    "30d2e1f4-00c7-42cf-b058-9e8845b5a61b" : {
      "Button_1" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ],
      "Button_2" : [
        "411b77b9-0fdc-461b-b1f8-4e8232a709a7"
      ],
      "Button_3" : [
        "de3fa695-1708-4fae-a804-a695e8b3ac17"
      ],
      "Button_4" : [
        "2eae7366-3a01-4b30-8e46-12da7958a706"
      ]
    },
    "de3fa695-1708-4fae-a804-a695e8b3ac17" : {
      "Image_2" : [
        "338bacdb-a63d-468d-a909-9271740becd8"
      ],
      "Image_3" : [
        "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"
      ],
      "Button_1" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ],
      "Button_2" : [
        "411b77b9-0fdc-461b-b1f8-4e8232a709a7"
      ],
      "Button_3" : [
        "de3fa695-1708-4fae-a804-a695e8b3ac17"
      ],
      "Button_4" : [
        "2eae7366-3a01-4b30-8e46-12da7958a706"
      ]
    },
    "64e355e8-cbf2-4945-b8e9-0f2807aec862" : {
      "Button_1" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ],
      "Button_2" : [
        "411b77b9-0fdc-461b-b1f8-4e8232a709a7"
      ],
      "Button_3" : [
        "de3fa695-1708-4fae-a804-a695e8b3ac17"
      ],
      "Button_4" : [
        "2eae7366-3a01-4b30-8e46-12da7958a706"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_2" : [
        "fe0140cd-a3a3-4d96-8def-0ed0454203b8"
      ]
    },
    "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632" : {
      "Button_1" : [
        "875096b0-3993-43a9-9643-053c9785c00d"
      ],
      "Button_3" : [
        "411b77b9-0fdc-461b-b1f8-4e8232a709a7"
      ],
      "Button_5" : [
        "de3fa695-1708-4fae-a804-a695e8b3ac17"
      ],
      "Button_6" : [
        "2eae7366-3a01-4b30-8e46-12da7958a706"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);