	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Image_1", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Button_2", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Filled", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_1", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Filled", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_3", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Filled", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Filled", "s-Button_4"]; 

	widgets.descriptionMap[["s-Rectangle_3", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_1", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_2", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_3", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_4", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_4", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Bar with labels", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Button_5", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_6", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_7", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_8", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ""; 

			widgets.rootWidgetMap[["s-Button_8", "1c44d7cd-c1f0-4bdd-9dec-08ab73bb0277"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_1", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_20", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Grid card", "s-Group_40"]; 

	widgets.descriptionMap[["s-Paragraph_34", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_34", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Title Medium", "s-Paragraph_34"]; 

	widgets.descriptionMap[["s-Paragraph_36", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_36", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Body small", "s-Paragraph_36"]; 

	widgets.descriptionMap[["s-Image_5", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Grid card", "s-Group_40"]; 

	widgets.descriptionMap[["s-Rectangle_24", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_24", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Grid card", "s-Group_42"]; 

	widgets.descriptionMap[["s-Paragraph_37", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_37", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Title Medium", "s-Paragraph_37"]; 

	widgets.descriptionMap[["s-Paragraph_39", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_39", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Body small", "s-Paragraph_39"]; 

	widgets.descriptionMap[["s-Image_10", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_10", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Grid card", "s-Group_42"]; 

	widgets.descriptionMap[["s-Rectangle_25", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_25", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Grid card", "s-Group_43"]; 

	widgets.descriptionMap[["s-Paragraph_40", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_40", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Title Medium", "s-Paragraph_40"]; 

	widgets.descriptionMap[["s-Paragraph_41", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_41", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Body small", "s-Paragraph_41"]; 

	widgets.descriptionMap[["s-Image_11", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_11", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Grid card", "s-Group_43"]; 

	widgets.descriptionMap[["s-Rectangle_26", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_26", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Grid card", "s-Group_44"]; 

	widgets.descriptionMap[["s-Paragraph_42", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_42", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Title Medium", "s-Paragraph_42"]; 

	widgets.descriptionMap[["s-Paragraph_43", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_43", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Body small", "s-Paragraph_43"]; 

	widgets.descriptionMap[["s-Image_6", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Grid card", "s-Group_44"]; 

	widgets.descriptionMap[["s-Path_27", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Path_27", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Grid", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_50", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_50", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Title Large", "s-Paragraph_50"]; 

	widgets.descriptionMap[["s-Rectangle_2", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_1", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_2", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_3", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_4", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_4", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Bar with labels", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Button_1", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_2", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_3", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_4", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "411b77b9-0fdc-461b-b1f8-4e8232a709a7"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_1", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Maps", "s-Group_16"]; 

	widgets.descriptionMap[["s-Rectangle_9", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["FAB", "s-Group_15"]; 

	widgets.descriptionMap[["s-Path_100", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_100", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["FAB", "s-Group_15"]; 

	widgets.descriptionMap[["s-Hotspot_2", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["FAB", "s-Group_15"]; 

	widgets.descriptionMap[["s-Ellipse_22", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_22", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Maps", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_78", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_78", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Maps", "s-Group_16"]; 

	widgets.descriptionMap[["s-Hotspot_5", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_5", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Maps", "s-Group_16"]; 

	widgets.descriptionMap[["s-Input_7", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_7", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Search", "s-Group_59"]; 

	widgets.descriptionMap[["s-Path_79", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_79", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Search", "s-Group_59"]; 

	widgets.descriptionMap[["s-Button_11", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Button_11", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Tabs", "s-Group_41"]; 

	widgets.descriptionMap[["s-Button_12", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Button_12", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Tabs", "s-Group_41"]; 

	widgets.descriptionMap[["s-Image", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_2", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_3", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Path_386", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_386", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["User", "s-Path_386"]; 

	widgets.descriptionMap[["s-Path_276", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_276", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Business", "s-Path_276"]; 

	widgets.descriptionMap[["s-Path_215", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_215", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Near me", "s-Path_215"]; 

	widgets.descriptionMap[["s-Path_164", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_164", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Store", "s-Path_164"]; 

	widgets.descriptionMap[["s-Path_277", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_277", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Business", "s-Path_277"]; 

	widgets.descriptionMap[["s-Path_287", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_287", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Account balance", "s-Path_287"]; 

	widgets.descriptionMap[["s-Path_42", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_42", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Search", "s-Path_42"]; 

	widgets.descriptionMap[["s-Button_13", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Button_13", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Tabs", "s-Group_42"]; 

	widgets.descriptionMap[["s-Button_14", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Button_14", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Tabs", "s-Group_42"]; 

	widgets.descriptionMap[["s-Button_1", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Tabs", "s-Group_42"]; 

	widgets.descriptionMap[["s-Button_2", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Tabs", "s-Group_42"]; 

	widgets.descriptionMap[["s-Rectangle_2", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_1", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_3", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_2", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_4", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_6", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_6", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_4", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_2", "875096b0-3993-43a9-9643-053c9785c00d"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "875096b0-3993-43a9-9643-053c9785c00d"]] = ["Bar with labels", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Image_1", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Button_2", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Filled", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_1", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Filled", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_3", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Filled", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Filled", "s-Button_4"]; 

	widgets.descriptionMap[["s-Rectangle_3", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_1", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_2", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_3", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_4", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_4", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Bar with labels", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Button_5", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_6", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_7", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_8", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ""; 

			widgets.rootWidgetMap[["s-Button_8", "2eae7366-3a01-4b30-8e46-12da7958a706"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_171", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_171", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Send", "s-Path_171"]; 

	widgets.descriptionMap[["s-Rectangle_6", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Button_2", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Path_6", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Path_7", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Mask_2", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_2", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Ellipse_2", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Path_18", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Ellipse_3", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Path_16", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Path_15", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Path_9", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Path_10", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Paragraph_9", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Title Large", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_7", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Body medium", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Mask_1", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Mask_1", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Path_99", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_99", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Path_100", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_100", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Path_101", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_101", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Path_102", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_102", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Paragraph_44", "338bacdb-a63d-468d-a909-9271740becd8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_44", "338bacdb-a63d-468d-a909-9271740becd8"]] = ["Videocall", "s-Group_24"]; 

	widgets.descriptionMap[["s-Image_1", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Button_2", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Filled", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_1", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Filled", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_3", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Filled", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Filled", "s-Button_4"]; 

	widgets.descriptionMap[["s-Rectangle_3", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_1", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_2", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_3", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_4", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_4", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Bar with labels", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Button_5", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_6", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_7", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_8", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_8", "3d4100d3-c9a0-4a70-87c5-1bd2d9038ca5"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_12", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Grid card", "s-Group_33"]; 

	widgets.descriptionMap[["s-Image_1", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Grid card", "s-Group_33"]; 

	widgets.descriptionMap[["s-Paragraph_20", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_20", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Title Medium", "s-Paragraph_20"]; 

	widgets.descriptionMap[["s-Image_2", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Rectangle_8", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Dropdown", "s-Dropdown_3"]; 

	widgets.descriptionMap[["s-Input_6", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Input_6", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Input field", "s-Input_6"]; 

	widgets.descriptionMap[["s-Path_5", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Dropdown", "s-Dropdown_3"]; 

	widgets.descriptionMap[["s-Path_6", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Dropdown", "s-Dropdown_3"]; 

	widgets.descriptionMap[["s-Bg", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Horizontal", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Rectangle_6", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Horizontal", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Paragraph_9", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Horizontal", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Path_13", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Star outline", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_16", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Star", "s-Path_16"]; 

	widgets.descriptionMap[["s-Rectangle_7", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Horizontal", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Paragraph_10", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Horizontal", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Path_10", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Star outline", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_9", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Star", "s-Path_9"]; 

	widgets.descriptionMap[["s-Item_3", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Item_3", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Horizontal", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Paragraph_6", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Horizontal", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Path_12", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Star outline", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_8", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Star", "s-Path_8"]; 

	widgets.descriptionMap[["s-Item_2", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Item_2", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Horizontal", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Paragraph_7", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Horizontal", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Path_14", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Star outline", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_7", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Star", "s-Path_7"]; 

	widgets.descriptionMap[["s-Item_1", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Item_1", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Horizontal", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Paragraph_8", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Horizontal", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Path_15", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Star outline", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_11", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Star", "s-Path_11"]; 

	widgets.descriptionMap[["s-Rectangle_1", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_1", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_2", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_3", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_4", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_4", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Bar with labels", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Button_5", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Tabs", "s-Group_7"]; 

	widgets.descriptionMap[["s-Button_6", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Tabs", "s-Group_7"]; 

	widgets.descriptionMap[["s-Button_7", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Tabs", "s-Group_7"]; 

	widgets.descriptionMap[["s-Button_8", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ""; 

			widgets.rootWidgetMap[["s-Button_8", "80623ed8-ddf5-4843-b252-67610c3fa5b2"]] = ["Tabs", "s-Group_7"]; 

	widgets.descriptionMap[["s-Image_3", "fe0140cd-a3a3-4d96-8def-0ed0454203b8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "fe0140cd-a3a3-4d96-8def-0ed0454203b8"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image", "fe0140cd-a3a3-4d96-8def-0ed0454203b8"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "fe0140cd-a3a3-4d96-8def-0ed0454203b8"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "fe0140cd-a3a3-4d96-8def-0ed0454203b8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "fe0140cd-a3a3-4d96-8def-0ed0454203b8"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "fe0140cd-a3a3-4d96-8def-0ed0454203b8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "fe0140cd-a3a3-4d96-8def-0ed0454203b8"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Button_2", "fe0140cd-a3a3-4d96-8def-0ed0454203b8"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "fe0140cd-a3a3-4d96-8def-0ed0454203b8"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Image_1", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Input_7", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Input_7", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Switch", "s-Input_7"]; 

	widgets.descriptionMap[["s-Path_66", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_66", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Medium", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Path_67", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_67", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Medium", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Path_70", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_70", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Medium", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Path_57", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_57", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Medium", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Rectangle_9", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Medium", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Paragraph_40", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_40", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Title Large", "s-Paragraph_40"]; 

	widgets.descriptionMap[["s-Path_82", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_82", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Medium", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Path_83", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_83", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Medium", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Path_84", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_84", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Medium", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Path_85", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_85", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Medium", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Paragraph_43", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_43", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Medium", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Panel_3", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_3", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Medium", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_1", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_2", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_3", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_4", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_4", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Bar with labels", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Button_1", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_2", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_3", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_4", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "622d7dd8-ad38-42cc-83d1-7bc2f77c922b"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_1", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Path_171", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_171", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Send", "s-Path_171"]; 

	widgets.descriptionMap[["s-Rectangle_1", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_1", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_2", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_3", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_4", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_4", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Bar with labels", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Button_1", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_2", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_3", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_4", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "30d2e1f4-00c7-42cf-b058-9e8845b5a61b"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_200", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_200", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_7", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_7", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_57", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_57", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Body large", "s-Paragraph_57"]; 

	widgets.descriptionMap[["s-Path_207", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_207", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_201", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_201", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_6", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_58", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_58", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Body large", "s-Paragraph_58"]; 

	widgets.descriptionMap[["s-Path_208", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_208", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_202", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_202", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_59", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_59", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Body large", "s-Paragraph_59"]; 

	widgets.descriptionMap[["s-Ellipse_9", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_9", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_209", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_209", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_203", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_203", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_10", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_10", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_61", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_61", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Body large", "s-Paragraph_61"]; 

	widgets.descriptionMap[["s-Path_210", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_210", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_204", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_204", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_11", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_11", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_64", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_64", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Body large", "s-Paragraph_64"]; 

	widgets.descriptionMap[["s-Path_211", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_211", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_205", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_205", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_119", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Path_119", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Arrow down", "s-Path_119"]; 

	widgets.descriptionMap[["s-Image_1", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_3", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Rectangle_3", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_1", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_2", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_3", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_4", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_4", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Bar with labels", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Button_1", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_2", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_3", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_4", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "de3fa695-1708-4fae-a804-a695e8b3ac17"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_1", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Input_7", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Input_7", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Switch", "s-Input_7"]; 

	widgets.descriptionMap[["s-Rectangle_3", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_1", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_2", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_3", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_4", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_4", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Bar with labels", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Button_1", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_2", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_3", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_4", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "64e355e8-cbf2-4945-b8e9-0f2807aec862"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Button_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_1", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Button_2", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Filled", "s-Button_2"]; 

	widgets.descriptionMap[["s-Image_3", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Image", "s-Image_4"]; 

	widgets.descriptionMap[["s-Button_4", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Outlined", "s-Button_4"]; 

	widgets.descriptionMap[["s-Path_248", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Path_248", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Thumb up", "s-Path_248"]; 

	widgets.descriptionMap[["s-Rectangle_3", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_1", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_1", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_2", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_2", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_3", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Hotspot_4", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_4", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Bar with labels", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Button_1", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_3", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_5", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Tabs", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_6", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "96b0c30d-6f69-4aef-bcb6-ca9ef1dd3632"]] = ["Tabs", "s-Group_1"]; 

	